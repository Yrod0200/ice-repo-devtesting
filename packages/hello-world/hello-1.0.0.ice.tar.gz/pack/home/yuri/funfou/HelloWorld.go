package funfou

import (
	"fmt"
)

func main() {
	fmt.Println("Hello, World!")
}
